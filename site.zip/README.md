# alya-gurme
### Сайт разработан для конкурса цифровой ветер - 2021.
### Автор: Исаев Тимур
#### Сайт работает на php, mysql, html, css


![alt-Логотип](http://digitalwind.ru/images/ru_logo_21.png "Логотип")