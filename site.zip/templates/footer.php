<div class="footer">
	<div>
		Сайт разработан специально для конкурса "Цифровой ветер - 2021" разработчиком Исаевым Тимуром
	</div>
  <div>
  	<?php echo date('Y');?> &copy;  <?php echo SITE_NAME;?> 
  </div>

  <div style="text-align: center;width:143px;margin:17px auto;">
    <a href="//www.digitalwind.ru" target="_blank">
    <img id="bxid_862078" src="/image/лого2021.png" title="www.digitalwind.ru" border="0" align="left" alt="www.digitalwind.ru" width="143" height="51" />
</a>


  </div>
</div>